# projeto_ia
Modelo de inteligência artificial para calcular as principais regiões com maiores indices de evasão escolar.
