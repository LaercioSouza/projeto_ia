# ============================================================
# 1. Imports
# ============================================================
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import classification_report, confusion_matrix
import matplotlib.pyplot as plt

# ============================================================
# 2. Carregar dataset
# ============================================================
df = pd.read_csv('microdados_ed_basica_2022.csv',
                 encoding='latin1',
                 sep=';',
                 low_memory=False)

# ============================================================
# 3. CRIAR ÍNDICE MUNICIPAL DE EVASÃO (NOVA ABORDAGEM)
# ============================================================

# Primeiro, vamos verificar quais colunas de matrícula existem no dataset
colunas_matricula = ['QT_MAT_INF', 'QT_MAT_FUND_AI', 'QT_MAT_FUND_AF', 
                    'QT_MAT_MED', 'QT_MAT_EJA', 'QT_MAT_PROF',
                    'QT_MAT_ABANDONO', 'QT_MAT_TRANSFERENCIA_SAIDA', 'QT_REPROVADOS']

# Filtrar colunas existentes
colunas_existentes = [c for c in colunas_matricula if c in df.columns]
print("Colunas de matrícula disponíveis:", colunas_existentes)

# Calcular total de matrículas por escola
df['TOTAL_MATRICULAS'] = 0
for coluna in ['QT_MAT_INF', 'QT_MAT_FUND_AI', 'QT_MAT_FUND_AF', 
               'QT_MAT_MED', 'QT_MAT_EJA', 'QT_MAT_PROF']:
    if coluna in df.columns:
        df['TOTAL_MATRICULAS'] += df[coluna].fillna(0)

# Calcular índice de evasão por escola (proporção EJA/total)
df['INDICE_EVASAO_ESCOLA'] = df['QT_MAT_EJA'] / df['TOTAL_MATRICULAS']
df['INDICE_EVASAO_ESCOLA'] = df['INDICE_EVASAO_ESCOLA'].replace([np.inf, -np.inf], 0).fillna(0)

# ============================================================
# 4. AGRUPAR POR MUNICÍPIO E CRIAR RANKING
# ============================================================

# Agrupar por município e calcular estatísticas
evasao_municipal = df.groupby(['CO_REGIAO', 'CO_UF', 'NO_MUNICIPIO']).agg({
    'INDICE_EVASAO_ESCOLA': 'mean',
    'TOTAL_MATRICULAS': 'sum',
    'QT_MAT_EJA': 'sum'
}).reset_index()

# Renomear colunas
evasao_municipal = evasao_municipal.rename(
    columns={'INDICE_EVASAO_ESCOLA': 'INDICE_EVASAO_MUNICIPAL'}
)

# Ordenar por índice de evasão (maior para menor)
ranking_evasao = evasao_municipal.sort_values('INDICE_EVASAO_MUNICIPAL', ascending=False)

# Mostrar top 50 municípios com maior índice de evasão
print("\n=== TOP 50 MUNICÍPIOS COM MAIOR ÍNDICE DE EVASÃO ===")
print(ranking_evasao.head(50)[['CO_REGIAO', 'CO_UF', 'NO_MUNICIPIO', 'INDICE_EVASAO_MUNICIPAL']])

# ============================================================
# 5. ANÁLISE REGIONAL DOS RESULTADOS
# ============================================================

# Contar quantos municípios por região estão no top 50
top_50 = ranking_evasao.head(50)
distribuicao_regional = top_50['CO_REGIAO'].value_counts()
print(f"\n=== DISTRIBUIÇÃO REGIONAL NO TOP 50 ===")
print(distribuicao_regional)

# Distribuição por UF no top 50
distribuicao_uf = top_50['CO_UF'].value_counts()
print(f"\n=== DISTRIBUIÇÃO POR UF NO TOP 50 ===")
print(distribuicao_uf)

# ============================================================
# 6. PREPARAR DADOS PARA O MODELO RANDOM FOREST
# ============================================================

# Juntar o índice municipal de evasão com os dados originais das escolas
df_com_indice = df.merge(
    evasao_municipal[['CO_UF', 'NO_MUNICIPIO', 'INDICE_EVASAO_MUNICIPAL']],
    on=['CO_UF', 'NO_MUNICIPIO'],
    how='left'
)

# Selecionar variáveis para o modelo (incluindo o índice municipal)
variaveis_entrada = [
    'CO_REGIAO', 'CO_UF', 'TP_DEPENDENCIA', 'TP_LOCALIZACAO',
    'QT_MAT_INF', 'QT_MAT_FUND_AI', 'QT_MAT_FUND_AF',
    'QT_MAT_MED', 'QT_MAT_EJA', 'QT_MAT_PROF',
    'QT_DOCENTE', 'QT_TUR_FUND_AI', 'QT_TUR_FUND_AF',
    'QT_TUR_MED', 'QT_TUR_EJA', 'INDICE_EVASAO_MUNICIPAL'
]

# Filtrar apenas colunas existentes
variaveis_entrada = [c for c in variaveis_entrada if c in df_com_indice.columns]

df_modelo = df_com_indice[variaveis_entrada].copy()

# ============================================================
# 7. CRIAR VARIÁVEL ALVO MELHORADA
# ============================================================

# Usar o índice municipal para definir evasão alta
# Consideraremos como "alta evasão" escolas em municípios com índice acima da mediana nacional
limiar_evasao = df_com_indice['INDICE_EVASAO_MUNICIPAL'].median()
df_modelo["EVASAO_ALTA"] = (df_com_indice['INDICE_EVASAO_MUNICIPAL'] > limiar_evasao).astype(int)

print(f"\nLimiar de evasão alta: {limiar_evasao:.4f}")
print(f"Proporção de escolas com evasão alta: {df_modelo['EVASAO_ALTA'].mean():.2%}")

# ============================================================
# 8. LIMPEZA E PREPARAÇÃO FINAL
# ============================================================

# Remover linhas incompletas
df_modelo = df_modelo.dropna()

# Separar X e y
X = df_modelo.drop("EVASAO_ALTA", axis=1)
y = df_modelo["EVASAO_ALTA"]

print(f"\nDimensões finais do dataset: {X.shape}")

# ============================================================
# 9. DIVISÃO TREINO/TESTE
# ============================================================
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y
)

# ============================================================
# 10. TREINAR RANDOM FOREST
# ============================================================
modelo = RandomForestClassifier(
    n_estimators=300,
    max_depth=None,
    random_state=42,
    n_jobs=-1
)

modelo.fit(X_train, y_train)

# ============================================================
# 11. AVALIAÇÃO DO MODELO
# ============================================================
y_pred = modelo.predict(X_test)

print("\n=== MATRIZ DE CONFUSÃO ===")
print(confusion_matrix(y_test, y_pred))

print("\n=== RELATÓRIO DE CLASSIFICAÇÃO ===")
print(classification_report(y_test, y_pred))

# ============================================================
# 12. IMPORTÂNCIA DAS VARIÁVEIS
# ============================================================
importancias = pd.DataFrame({
    "variavel": X.columns,
    "importancia": modelo.feature_importances_
}).sort_values("importancia", ascending=False)

print("\n=== IMPORTÂNCIA DAS VARIÁVEIS (COM ÍNDICE MUNICIPAL) ===")
print(importancias)

# ============================================================
# 13. VISUALIZAÇÃO DAS IMPORTÂNCIAS (COM NOMES MELHORADOS)
# ============================================================

# Criar um dicionário de mapeamento para nomes mais amigáveis
mapeamento_variaveis = {
    'CO_REGIAO': 'Região Geográfica',
    'CO_UF': 'Unidade Federativa (UF)',
    'TP_DEPENDENCIA': 'Tipo de Dependência Administrativa',
    'TP_LOCALIZACAO': 'Localização da Escola',
    'QT_MAT_INF': 'Matrículas - Educação Infantil',
    'QT_MAT_FUND_AI': 'Matrículas - Anos Iniciais do Fundamental',
    'QT_MAT_FUND_AF': 'Matrículas - Anos Finais do Fundamental', 
    'QT_MAT_MED': 'Matrículas - Ensino Médio',
    'QT_MAT_EJA': 'Matrículas - Educação de Jovens e Adultos',
    'QT_MAT_PROF': 'Matrículas - Educação Profissional',
    'QT_DOCENTE': 'Número Total de Docentes',
    'QT_TUR_FUND_AI': 'Número de Turmas - Fundamental Anos Iniciais',
    'QT_TUR_FUND_AF': 'Número de Turmas - Fundamental Anos Finais',
    'QT_TUR_MED': 'Número de Turmas - Ensino Médio',
    'QT_TUR_EJA': 'Número de Turmas - EJA',
    'INDICE_EVASAO_MUNICIPAL': 'Índice Municipal de Evasão Escolar'
}

# Aplicar o mapeamento às importâncias
importancias_renomeadas = importancias.copy()
importancias_renomeadas['variavel_renomeada'] = importancias_renomeadas['variavel'].map(mapeamento_variaveis)

# Para variáveis que não estão no mapeamento, manter o nome original
importancias_renomeadas['variavel_renomeada'] = importancias_renomeadas['variavel_renomeada'].fillna(importancias_renomeadas['variavel'])

plt.figure(figsize=(12, 8))
bars = plt.barh(importancias_renomeadas['variavel_renomeada'][:10], 
                importancias_renomeadas['importancia'][:10],
                color='steelblue', alpha=0.8)

# Adicionar valores nas barras
for bar in bars:
    width = bar.get_width()
    plt.text(width + 0.001, bar.get_y() + bar.get_height()/2, 
             f'{width:.3f}', ha='left', va='center', fontsize=10)

plt.xlabel('Importância Relativa', fontsize=12)
plt.ylabel('Variáveis', fontsize=12)
plt.title('Top 10 Variáveis Mais Importantes para Prever Evasão Escolar', 
          fontsize=14, fontweight='bold')
plt.gca().invert_yaxis()
plt.grid(axis='x', alpha=0.3)
plt.tight_layout()
plt.show()

# Mostrar a tabela com os nomes renomeados
print("\n=== IMPORTÂNCIA DAS VARIÁVEIS (NOMES MELHORADOS) ===")
print(importancias_renomeadas[['variavel_renomeada', 'importancia']].head(15))

# ============================================================
# 14. ANÁLISE DETALHADA DO RANKING MUNICIPAL (MELHORADA)
# ============================================================

# Mapear códigos de região para nomes
mapa_regioes = {
    1: 'Norte',
    2: 'Nordeste', 
    3: 'Sudeste',
    4: 'Sul',
    5: 'Centro-Oeste'
}

# Mapear códigos de UF para nomes
mapa_uf = {
    11: 'RO', 12: 'AC', 13: 'AM', 14: 'RR', 15: 'PA', 16: 'AP', 17: 'TO',
    21: 'MA', 22: 'PI', 23: 'CE', 24: 'RN', 25: 'PB', 26: 'PE', 27: 'AL', 28: 'SE', 29: 'BA',
    31: 'MG', 32: 'ES', 33: 'RJ', 35: 'SP',
    41: 'PR', 42: 'SC', 43: 'RS',
    50: 'MS', 51: 'MT', 52: 'GO', 53: 'DF'
}

# Mapear tipos de dependência para nomes mais compreensíveis
mapa_dependencia = {
    1: 'Federal',
    2: 'Estadual',
    3: 'Municipal',
    4: 'Privada'
}

# Mapear localização
mapa_localizacao = {
    1: 'Urbana',
    2: 'Rural'
}

# Aplicar mapeamentos
ranking_detalhado = ranking_evasao.head(50).copy()
ranking_detalhado['REGIAO_NOME'] = ranking_detalhado['CO_REGIAO'].map(mapa_regioes)
ranking_detalhado['UF_SIGLA'] = ranking_detalhado['CO_UF'].map(mapa_uf)

print("\n=== TOP 10 MUNICÍPIOS - RANKING DETALHADO ===")
print(f"{'Pos':<4}{'Região':<12}{'UF':<4}{'Município':<30}{'Índice Evasão':<15}")
print("-" * 70)
for i, (idx, row) in enumerate(ranking_detalhado.head(10).iterrows(), 1):
    print(f"{i:<4}{row['REGIAO_NOME']:<12}{row['UF_SIGLA']:<4}{row['NO_MUNICIPIO']:<30}{row['INDICE_EVASAO_MUNICIPAL']:.4f}")

# Visualização melhorada do ranking municipal
plt.figure(figsize=(14, 10))
top_10_municipios = ranking_detalhado.head(10)

# Criar barras coloridas por região
cores_regioes = {
    'Norte': '#1f77b4',
    'Nordeste': '#ff7f0e', 
    'Sudeste': '#2ca02c',
    'Sul': '#d62728',
    'Centro-Oeste': '#9467bd'
}

cores = [cores_regioes[regiao] for regiao in top_10_municipios['REGIAO_NOME']]

bars = plt.barh(range(10), 
                top_10_municipios['INDICE_EVASAO_MUNICIPAL'],
                color=cores, alpha=0.8)

plt.yticks(range(10), [f"{row['NO_MUNICIPIO']}\n({row['UF_SIGLA']})" 
                       for _, row in top_10_municipios.iterrows()])
plt.xlabel('Índice de Evasão Municipal', fontsize=12)
plt.title('Top 10 Municípios com Maior Índice de Evasão Escolar', 
          fontsize=14, fontweight='bold')
plt.grid(axis='x', alpha=0.3)

# Adicionar valores nas barras
for i, (bar, row) in enumerate(zip(bars, top_10_municipios.iterrows())):
    width = bar.get_width()
    plt.text(width + 0.001, i, f'{width:.4f}', va='center', fontsize=10, fontweight='bold')

# Adicionar legenda de cores por região
from matplotlib.patches import Patch
legend_elements = [Patch(facecolor=color, label=regiao) 
                   for regiao, color in cores_regioes.items()]
plt.legend(handles=legend_elements, loc='lower right', title='Regiões')

plt.tight_layout()
plt.show()

# Gráfico de distribuição regional no top 50
plt.figure(figsize=(10, 6))
distribuicao_regional_nomes = top_50['CO_REGIAO'].map(mapa_regioes).value_counts()
distribuicao_regional_nomes.plot(kind='pie', autopct='%1.1f%%', startangle=90, 
                                 colors=[cores_regioes[reg] for reg in distribuicao_regional_nomes.index])
plt.title('Distribuição Regional dos 50 Municípios com Maior Evasão', fontsize=14, fontweight='bold')
plt.ylabel('')
plt.tight_layout()
plt.show()

# ============================================================
# 15. ESTATÍSTICAS GERAIS (MELHORADAS)
# ============================================================
print(f"\n=== ESTATÍSTICAS GERAIS DO ÍNDICE DE EVASÃO MUNICIPAL ===")
print(f"Total de municípios analisados: {len(evasao_municipal):,}")
print(f"Média nacional: {evasao_municipal['INDICE_EVASAO_MUNICIPAL'].mean():.4f}")
print(f"Mediana nacional: {evasao_municipal['INDICE_EVASAO_MUNICIPAL'].median():.4f}")
print(f"Desvio padrão: {evasao_municipal['INDICE_EVASAO_MUNICIPAL'].std():.4f}")
print(f"Máximo: {evasao_municipal['INDICE_EVASAO_MUNICIPAL'].max():.4f}")
print(f"Mínimo: {evasao_municipal['INDICE_EVASAO_MUNICIPAL'].min():.4f}")

# Estatísticas por região
print(f"\n=== ESTATÍSTICAS POR REGIÃO ===")
evasao_municipal['REGIAO_NOME'] = evasao_municipal['CO_REGIAO'].map(mapa_regioes)
estatisticas_regiao = evasao_municipal.groupby('REGIAO_NOME')['INDICE_EVASAO_MUNICIPAL'].agg([
    'count', 'mean', 'median', 'std', 'min', 'max'
]).round(4)
print(estatisticas_regiao)

# ============================================================
# 16. EXPORTAR RESULTADOS (OPCIONAL)
# ============================================================
# Exportar ranking para CSV
ranking_detalhado.to_csv('ranking_evasao_municipal.csv', index=False, encoding='utf-8-sig')
print(f"\nRanking exportado para 'ranking_evasao_municipal.csv'")

# Exportar importância das variáveis
importancias_renomeadas[['variavel_renomeada', 'importancia']].to_csv(
    'importancia_variaveis_evasao.csv', index=False, encoding='utf-8-sig'
)
print("Importância das variáveis exportada para 'importancia_variaveis_evasao.csv'")